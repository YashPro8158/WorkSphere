
const currentUser = JSON.parse(localStorage.getItem("currentuser"));
const action = document.getElementById("actioncheck");
const loginbutton = document.getElementById("loginbtn");
const signupbutton = document.getElementById("signupbtn");
const notescount = document.getElementById("notescount");
const taskcount = document.getElementById("taskcount");
const expensescount = document.getElementById("expensescount");
const allregisterusers = JSON.parse(localStorage.getItem('registerusers') || '[]');
// finding the Current user index in all register user
let userindex = allregisterusers.findIndex(user => user.emailid.toLowerCase() === currentUser.emailid);

document.getElementById("logo").addEventListener("click", () => {

    window.location.href = "index.html";
})
if (currentUser) {
    // showing username on top
    document.getElementById("username").innerText = currentUser.username;
    // logout logic
    document.getElementById("logout").addEventListener("click", () => {
        localStorage.removeItem("currentuser");
        window.location.href = "login.html";
    })



}
else {
    window.location.href = "login.html";
}

